# San Julian de Cuenca Parish Church - Public Deployment

## Local test
1. Activate the virtual environment.
2. Install dependencies: `pip install -r requirements.txt`
3. Create `.env` locally with `OPENAI_API_KEY=your_key` and a strong `FLASK_SECRET_KEY`.
4. Run: `python app.py`
5. Open: `http://127.0.0.1:5000/public`

## Render deployment
1. Push this folder to a private GitHub repository.
2. In Render, create a new Web Service from the repository.
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `gunicorn --bind 0.0.0.0:$PORT app:app`
5. Add environment variables in Render:
   - `OPENAI_API_KEY` = your real API key
   - `FLASK_SECRET_KEY` = a long random secret
   - `SESSION_COOKIE_SECURE` = `1`
6. Deploy. Render provides a public HTTPS `onrender.com` URL.

## Important
- Never commit `.env` or an API key to GitHub.
- SQLite on a free/ephemeral web service is suitable for testing/demo deployment but is not reliable for permanent parish records. For production, move the database to a persistent managed database or persistent storage.
- Change the default admin password immediately after first login.
